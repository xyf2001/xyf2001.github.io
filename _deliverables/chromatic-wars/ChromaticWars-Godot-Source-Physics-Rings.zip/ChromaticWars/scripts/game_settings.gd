class_name GameSettings
extends RefCounted
## 配置只写入 user://，不改工程或锁定资源。validate 总是返回可安全使用的完整配置。

const CONFIG_PATH := "user://chromatic_wars.cfg"
const CAPACITIES := [10000, 50000, 100000, 300000, 1000000]
const LIVE_KEYS := ["gravity", "restitution", "friction", "air_force", "air_height", "air_width", "air_exponent", "growth_target", "growth_duration", "radius_min", "radius_max", "radius_k", "gun_start", "gun_end", "gun_duration", "particle_cost_delay", "particle_cost_growth", "storm_ring_particles", "storm_ring_interval", "ball_speed", "sniper_speed", "sniper_charge_time", "shield_scale", "shield_max_diameter", "emergency_cd", "particle_radius", "trail_length", "visual_density", "fps_limit", "time_scale", "channel_width_8", "channel_width_4", "channel_width_2", "custom_pegs", "disabled_preset_pegs", "peg_radius"]

static func defaults() -> Dictionary:
	return {
		"gravity": 820.0, "restitution": 1.0, "friction": 0.0,
		"air_force": 2950.0, "air_height": 180.0, "air_width": 96.0, "air_exponent": 2.8,
		"growth_target": 1000000.0, "growth_duration": 1200.0,
		"radius_min": 4.2, "radius_max": 36.0, "radius_k": 3.0,
		"intro_shield": 1000000.0, "intro_gun": 1000000.0,
		"gun_start": 120.0, "gun_end": 1400.0, "gun_duration": 1200.0,
		"particle_cost_delay": 60.0, "particle_cost_growth": 0.25,
		"storm_ring_particles": 96, "storm_ring_interval": 0.10,
		"ball_speed": 92.0, "sniper_speed": 620.0, "sniper_charge_time": 0.65,
		"shield_scale": 1.0, "shield_max_diameter": 389.12,
		"channel_width_8": 37.0, "channel_width_4": 47.0, "channel_width_2": 67.0,
		"custom_pegs": [], "disabled_preset_pegs": [], "peg_radius": 6.0,
		"core_0_x": 256.0, "core_0_y": 256.0,
		"core_1_x": 768.0, "core_1_y": 256.0,
		"core_2_x": 256.0, "core_2_y": 768.0,
		"core_3_x": 768.0, "core_3_y": 768.0,
		"emergency_cd": 180.0, "particle_capacity": 10000,
		"grid_size": 512, "render_size": 768, "particle_radius": 1.2,
		"trail_length": 0.12, "visual_density": 1.0,
		"packet_energy": 1, "precision_mode": "exact", "fixed_dt": 1.0 / 120.0,
		"fps_limit": 60, "time_scale": 0.25, "seed": 20261016,
	}

static func load_file() -> Dictionary:
	var file := ConfigFile.new()
	if file.load(CONFIG_PATH) != OK:
		return defaults()
	var config := defaults()
	for key: String in config:
		config[key] = file.get_value("游戏", key, config[key])
	# Upgrade only the old default rate; retain deliberately customized rates.
	if not file.has_section_key("游戏", "particle_cost_growth") and is_equal_approx(float(config["gun_start"]), 42.0):
		config["gun_start"] = 120.0
	return validate(config)

static func save_file(config: Dictionary) -> Error:
	var file := ConfigFile.new()
	var validated := validate(config)
	for key: String in validated:
		file.set_value("游戏", key, validated[key])
	return file.save(CONFIG_PATH)

static func validate(config: Dictionary) -> Dictionary:
	var result := defaults()
	var limits := {
		"gravity": [50.0, 2000.0], "restitution": [0.05, 1.0], "friction": [0.0, 0.3],
		"air_force": [0.0, 12000.0], "air_height": [40.0, 280.0], "air_width": [30.0, 98.0],
		"air_exponent": [0.5, 8.0], "growth_target": [100.0, 1000000000.0],
		"growth_duration": [1.0, 7200.0], "radius_min": [4.0, 9.0],
		"radius_max": [12.0, 40.0], "radius_k": [0.1, 30.0],
		"intro_shield": [0.0, 1000000000.0], "intro_gun": [0.0, 1000000000.0],
		"gun_start": [0.0, 10000.0], "gun_end": [0.0, 1000000.0],
		"particle_cost_delay": [0.0, 7200.0], "particle_cost_growth": [0.0, 100.0],
		"storm_ring_interval": [0.02, 2.0],
		"gun_duration": [1.0, 7200.0], "ball_speed": [10.0, 500.0],
		"sniper_speed": [50.0, 2000.0], "sniper_charge_time": [0.0, 3.0],
		"shield_scale": [0.25, 3.0], "shield_max_diameter": [32.0, 768.0],
		"channel_width_8": [12.0, 100.0], "channel_width_4": [12.0, 100.0], "channel_width_2": [12.0, 100.0],
		"peg_radius": [3.0, 24.0],
		"core_0_x": [32.0, 992.0], "core_0_y": [32.0, 992.0],
		"core_1_x": [32.0, 992.0], "core_1_y": [32.0, 992.0],
		"core_2_x": [32.0, 992.0], "core_2_y": [32.0, 992.0],
		"core_3_x": [32.0, 992.0], "core_3_y": [32.0, 992.0],
		"emergency_cd": [0.0, 3600.0], "particle_radius": [0.5, 3.0],
		"trail_length": [0.0, 0.9], "visual_density": [0.05, 1.0],
		"fixed_dt": [1.0 / 480.0, 1.0 / 30.0], "time_scale": [0.25, 4.0],
	}
	for key: String in limits:
		var value: Variant = config.get(key, result[key])
		if (value is int or value is float) and is_finite(float(value)):
			result[key] = clampf(float(value), float(limits[key][0]), float(limits[key][1]))
	result["radius_max"] = maxf(float(result["radius_min"]), float(result["radius_max"]))
	# 左右各一组通道共用可用宽度；为中央空气通路与实体隔墙留足空间。
	var channel_total := float(result["channel_width_8"]) + float(result["channel_width_4"]) + float(result["channel_width_2"])
	if channel_total > 158.0:
		var width_factor := (158.0 - 36.0) / (channel_total - 36.0)
		result["channel_width_8"] = floorf((12.0 + (float(result["channel_width_8"]) - 12.0) * width_factor) * 1000.0) / 1000.0
		result["channel_width_4"] = floorf((12.0 + (float(result["channel_width_4"]) - 12.0) * width_factor) * 1000.0) / 1000.0
		result["channel_width_2"] = 158.0 - float(result["channel_width_8"]) - float(result["channel_width_4"])
	var custom_pegs: Array[Vector3] = []
	var supplied_pegs: Variant = config.get("custom_pegs", [])
	if supplied_pegs is Array:
		for entry: Variant in supplied_pegs:
			if entry is Vector3 and is_finite(entry.x) and is_finite(entry.y) and is_finite(entry.z):
				var peg_radius := clampf(entry.z, 3.0, 24.0)
				custom_pegs.append(Vector3(clampf(entry.x, 16.0 + peg_radius, 464.0 - peg_radius), clampf(entry.y, 130.0 + peg_radius, 750.0 - peg_radius), peg_radius))
				if custom_pegs.size() == 64:
					break
	result["custom_pegs"] = custom_pegs
	var disabled_preset_pegs: Array[int] = []
	var supplied_disabled: Variant = config.get("disabled_preset_pegs", [])
	if supplied_disabled is Array:
		for entry: Variant in supplied_disabled:
			if entry is int and entry >= 0 and entry < 15 and not entry in disabled_preset_pegs:
				disabled_preset_pegs.append(entry)
	disabled_preset_pegs.sort()
	result["disabled_preset_pegs"] = disabled_preset_pegs
	for key: String in ["particle_capacity", "grid_size", "render_size", "storm_ring_particles", "fps_limit", "seed"]:
		var value: Variant = config.get(key, result[key])
		if value is int or value is float:
			if is_finite(float(value)):
				result[key] = int(value)
	if not result["particle_capacity"] in CAPACITIES:
		result["particle_capacity"] = 10000
	if not result["grid_size"] in [256, 512, 768, 1024]:
		result["grid_size"] = 512
	if not result["render_size"] in [512, 768, 1024, 1536]:
		result["render_size"] = 768
	result["storm_ring_particles"] = clampi(int(result["storm_ring_particles"]), 12, 512)
	result["fps_limit"] = clampi(int(result["fps_limit"]), 0, 240)
	result["seed"] = clampi(int(result["seed"]), 0, 2147483647)
	# 旧配置的粒子包开关不再改变战斗规则；普通粒子使用出生时成本。
	result["precision_mode"] = "exact"
	result["packet_energy"] = 1
	if not float(result["fixed_dt"]) in [1.0 / 60.0, 1.0 / 120.0, 1.0 / 240.0]:
		result["fixed_dt"] = 1.0 / 120.0
	if not float(result["time_scale"]) in [0.25, 0.5, 1.0, 2.0, 4.0]:
		result["time_scale"] = 0.25
	return result
