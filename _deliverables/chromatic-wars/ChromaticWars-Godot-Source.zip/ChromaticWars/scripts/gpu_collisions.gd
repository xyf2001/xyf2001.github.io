class_name GPUCollisions
extends RefCounted
## 粒子空间分区和步长约束。具体碰撞在battle.glsl模式3/4/5完成。
## 16px格，普通半径<=3；9色中心格各3×3链表集合互不相交。
const WORLD_SIZE := 1024.0
const CELL_SIZE := 16.0
const SPATIAL_COLUMNS := 64
const COLOR_PHASES := 9

static func substep_count(dt: float, settings: Dictionary) -> int:
	# 按步末位置建桶，限制设置速度下每体位移<=4px，避免高速相穿漏候选。
	var speed := maxf(float(settings.get("sniper_speed", 600.0)), float(settings.get("particle_speed", 140.0)))
	speed = maxf(speed, float(settings.get("ball_speed", 42.0)))
	var max_dt := minf(1.0 / 120.0, 4.0 / maxf(speed, 1.0))
	return maxi(1, int(ceil(dt / max_dt)))
