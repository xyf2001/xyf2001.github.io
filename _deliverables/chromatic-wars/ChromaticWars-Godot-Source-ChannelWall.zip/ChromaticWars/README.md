# 颜色大战 · 显存战场

可编辑的 Godot 桌面游戏工程：左侧 16 颗真实圆刚体弹药球，右侧由 Vulkan Compute 维护粒子、领土、大球、护盾和核心。正式画面直接使用主 RenderingDevice 的 `Texture2DRD`，没有整帧 GPU→CPU→GPU 绘制路径。

当前为 **1.1.1-channel-wall 倍率槽底墙修复版**。在性能修复版基础上，仅给六个倍率槽加上实体底墙，阻挡下方反弹球误入；中央通路和正常倍率规则保持原样。右下“战场诊断”仍可复制设备、FPS和配置摘要；上一版的性能记录见`docs/性能修复记录.md`。

**请先读 `TEST_REPORT.md`。已完成的规则测试、软件 Vulkan 运行，与 Windows 实体显卡验收是不同结论。本版本不宣称全部验收清单已通过。**

## 运行与导出

推荐 **Godot 4.6.3 标准版**、Windows 10/11、支持 Vulkan 的独立或集成显卡及最新官方驱动。项目使用 Forward+。Godot 4.3 兼容分支仅对少量统计改用低频同步读回，未在4.3实测；4.6.3使用异步读回。需要可用的 RenderingDevice，失败会显示中文错误，不会回退为CPU战场。

编辑器与匹配的导出模板可从[Godot官方4.6.3发布页](https://github.com/godotengine/godot/releases/tag/4.6.3-stable)下载；本工程不需要.NET版。只运行已导出的EXE时无需安装编辑器。

1. 用 Godot 项目管理器导入 `project.godot`，等待资源导入完成。
2. 按 F6/F5 启动主场景。默认 0.25×、1万粒子槽、512²领土、768²渲染、逐粒子精确模式。
3. 若运行已导出的 Windows 版，解压整个构建包，再运行 `颜色大战.exe`。没有代码签名；是否能在具体机器运行仍需看显卡、驱动和系统。

手动重新导出：安装与编辑器完全同版本的官方导出模板，打开「项目 → 导出 → Windows 桌面」，选择 x86_64 并导出；或：

```sh
godot --headless --path . --export-release "Windows 桌面" export/颜色大战.exe
```

第一次导入 Compute 资源应在可用 Vulkan 的编辑器中进行，不要把无RenderingDevice的headless导入当成GPU验证。`export_presets.cfg` 已配置嵌入PCK；导出时读取标准 `RDShaderFile` 的SPIR-V，开发时可直接编译GLSL原文。

## 操作

- 空格：暂停/继续；N：暂停后单步；R：新开局；Tab：参数面板；F12：保存明确的一次性截图到 `user://`。
- 顶栏可选 0.25× / 0.5× / 1× / 2× / 4×、输入种子或生成新种子。
- 参数面板区分即时生效与新开局生效，提供保存、加载、恢复默认。配置保存在 `user://chromatic_wars.cfg`，不会覆盖工程。
- 「球详情」显示16球当前数值、真实物理半径、出生时锁定的门槛。
- 调试区的武器按钮是明确的人工调试发射，不属于正常对局的随机收益。

## 玩法与精度

四阵营固定为红左上、绿右上、蓝左下、黄右下，开局各25%领土、4颗数值2的弹药球、唯一护盾与机枪库存各1,000,000。

倍率由真实入口碰撞决定；完整圆进入×2/×4/×8后立即乘倍并重新发射。中央空气墙只按实际半径施力。底部连续输送带显示和命中共用一个滚动坐标，固定窗口计数与内容计数分开。

门槛默认严格为 `lerp(100, 1_000_000, clamp(t / 1200, 0, 1))`，每次完整输出后锁定新出生门槛；时间推进不会直接缩小已在场的球。最大球径72，大于最宽倍率口67、小于中央通道98；下层柱间净距为其留出空间。倍率累积可能非常大，CPU命令精确整数上限为2^53−1，越界时保留原值并暂停，绝不悄悄截断。

护盾、机枪、风暴、狙击、大球使用独立输出。风暴和狙击有持续发射储备，容量不足时保留能量。大球最多64颗，额外发射保留在命令队列。大球从核心外沿生成，能消耗领土、反弹、受粒子冲量影响并随剩余能量缩小。

GPU核心统一状态为：存活→保命待定→补盾存活/确认淘汰。待定请求在CPU读取前持续锁存；CPU只抽左侧最大球并回传能量，GPU决定生死与180模拟秒CD。死亡后库存变风暴、四颗左球变大球余波，不能复活。

逐粒子精确模式每个普通/狙击实体能量为1。能量包模式以显式整数能量代表多颗粒子，在场对象数不等于逻辑能量；整数抵消和逐格扣能量仍保留，但局部轨迹、压力分布及包撞盾后的剩余能量反射属于近似。面板显示当前模式与带能量粒子的比例；切回精确发射后，存量包耗尽前显示“新发射精确 · 存量包近似”，不会丢包或冒称全场逐粒子精确。

## 性能设置与限制

建议从默认精度开始，先看帧率和积压再增加容量。GPU容量选项为1万、5万、10万、30万、100万；分配前检查存储缓冲能力与预算。地图最高1024²、渲染最高1536²，以实际遥测为准。越高地图精度意味着大球每次扫掠需要处理更多格子。

当前为优先保证结算正确，粒子邻域碰撞使用九色空间链表，领土/护盾/大球事件使用一个GPU invocation顺序结算。**这是重大吞吐限制；没有实体显卡60FPS保证。** 软件Vulkan的性能数据不能外推到真实显卡；30万/100万硬件压力测试尚未执行。

固定步长与模拟时间控制CD；慢机器达到每帧步数预算时保留时间积压，界面速度是目标速度，实际模拟可能追不上。不靠跳过弹药或伤害维持表面帧率。详见测试报告中的未完成项。

## 模块

| 文件 | 职责 |
| --- | --- |
| scripts/main.gd | 固定步长、暂停/单步、输入、保命握手与生命周期 |
| scripts/pinball_physics.gd | 16颗CPU圆刚体、质量r²、实体冲量和出生循环 |
| scripts/multiplier_channels.gd | 六倍率口的碰撞多边形、净宽、完整圆判定和计数 |
| scripts/air_curtain.gd | 中央气流及半径响应 |
| scripts/weapon_conveyor.gd | 唯一滚动坐标、绘制与输出采样 |
| scripts/gpu_world.gd | 主RD资源、命令背压、pass屏障、纹理与小统计 |
| scripts/gpu_emitters.gd / gpu_collisions.gd / gpu_render.gd | 发射编码、子步策略、共享纹理资源 |
| shaders/battle.glsl | 发射、运动、空间链表、碰撞、领土、护盾核心、统计和GPU绘制的明确pass |
| scripts/battle_labels.gd | 少量GPU遥测的数字标签；不模拟右侧粒子 |
| scripts/game_settings.gd / game_ui.gd | 中文配置、界面与实时诊断 |
| tests / tools | 独立规则、压力、长局与真实窗口截图工具 |

缓冲布局和精度边界详见 `docs/GPU架构与精度.md` 与 `docs/GPU状态与同步.md`，参考工程问题详见 `docs/故障审查与修复计划.md`。

## 自动测试

```sh
python tools/run_tests.py --godot /path/to/godot --suite settings
python tools/run_tests.py --godot /path/to/godot --suite channel_floor
python tools/run_tests.py --godot /path/to/godot --suite cpu --duration 1200 --timeout 900
python tools/run_tests.py --godot /path/to/godot --suite gpu --timeout 300
python tools/run_tests.py --godot /path/to/godot --suite stress --capacity 100000 --timeout 300
```

GPU套件需要普通Vulkan窗口，Linux云机可配Xvfb与Lavapipe；`--headless`不能代替它。Windows在桌面会话中运行。所有套件保留原始日志与JSON；失败、未测试和实际通过分别记录，没有断言不会报PASS。`tools/visual_smoke.gd`验证完整主场景、截图、暂停和单步。`--suite battle --capacity 64 --duration 1200 --timeout 3600`可运行明确标注的64粒子/64²地图/4096能量包双系统对局工具；全灭时记录自然结束，不能把早于20分钟的自然结束叫20分钟稳定性通过。

`tools/export_pck_smoke.gd`可在Linux以`godot --main-pack /绝对路径/颜色大战.exe --script /工程外/该脚本副本.gd -- --artifact-dir /证据目录`验证导出资源。运行目录应在工程外且不传`--path`，防止误加载开发目录。该检查实际装载内嵌SPIR-V、核验开局状态、推进Compute并采样共享纹理画面，仍不等于Windows系统启动测试。

中文字体为Noto Sans CJK子集，许可见 `assets`。
