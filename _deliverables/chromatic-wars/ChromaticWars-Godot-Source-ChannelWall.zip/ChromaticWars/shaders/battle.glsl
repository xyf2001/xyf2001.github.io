#[compute]
#version 450
// 颜色大战：所有战场权威状态常驻主 RenderingDevice。
// std430: Particle=64B, Team=128B, Command=32B。CPU只读Team/64字统计。
// 每个dispatch之间必须插入compute barrier；9色碰撞每色单独dispatch。
layout(local_size_x=64, local_size_y=1, local_size_z=1) in;
struct Particle { vec4 pv; uvec4 info; vec4 geom; uvec4 aux; };
struct Team { uvec4 shield_gun; uvec4 storm_sniper; uvec4 life; vec4 clocks;
              uvec4 accounting; vec4 core; uvec4 misc; vec4 visual; };
struct Command { uvec4 a; uvec4 b; };
layout(set=0,binding=0,std430) restrict buffer Particles { Particle p[]; };
layout(set=0,binding=1,std430) restrict buffer Teams { Team team[]; };
layout(set=0,binding=2,std430) restrict buffer Territory { uint owner[]; };
layout(set=0,binding=3,std430) restrict buffer CellHeads { int head[]; };
layout(set=0,binding=4,std430) restrict buffer CellNext { int next_id[]; };
layout(set=0,binding=5,std430) restrict buffer Commands { Command command[]; };
layout(set=0,binding=6,std430) restrict buffer Metrics { uint stat[]; };
layout(rgba8,set=0,binding=7) uniform restrict writeonly image2D output_image;
layout(set=0,binding=8,std430) restrict buffer ParticlePixels { uint pixels[]; };
layout(set=0,binding=9,std430) readonly restrict buffer Parameters { vec4 par[]; };
layout(push_constant,std430) uniform Push { uvec4 control; vec4 clock; } pc;
// 领土计数随唯一的归属变更出口增量维护，避免周期性整图扫描。
const float TAU=6.28318530718;
uint cap() { return uint(par[0].x); }
uint balls() { return uint(par[1].w); }
uint total() { return cap()+balls(); }
uint terrain_size() { return uint(par[0].y); }
uint render_size() { return uint(par[0].z); }
uint cols() { return uint(par[1].z); }
float world() { return par[1].x; }
// GDScript整数为有符号64位：可表示的游戏能量域为0..2^63-1；超限保留输入命令并报错。
bool can_add64(uvec2 a,uvec2 b) { uint lo=a.x+b.x;uint high=a.y+b.y;uint carry=uint(lo<a.x);return high>=a.y&&high+carry>=high&&high+carry<=0x7fffffffu; }
uvec2 add64(uvec2 a,uvec2 b) { uint lo=a.x+b.x;uint high=a.y+b.y;uint result=high+uint(lo<a.x);if(high<a.y||result<high||result>0x7fffffffu){atomicOr(stat[15],1u);return uvec2(0xffffffffu,0x7fffffffu);}return uvec2(lo,result); }
bool less64(uvec2 a,uvec2 b) { return a.y<b.y || (a.y==b.y && a.x<b.x); }
bool zero64(uvec2 a) { return (a.x|a.y)==0u; }
uvec2 sub64(uvec2 a,uvec2 b) { return uvec2(a.x-b.x,a.y-b.y-uint(a.x<b.x)); }
uvec2 min64(uvec2 a,uvec2 b) { return less64(a,b)?a:b; }
float value64(uvec2 a) { return float(a.y)*4294967296.0+float(a.x); }
uvec2 energy(uint i) { return p[i].info.xy; }
void set_energy(uint i,uvec2 e) { p[i].info.xy=e; if(zero64(e)) p[i].info.w=0u; }
void spend(uint i,uvec2 amount) { set_energy(i,sub64(energy(i),amount)); }
void consumed(uvec2 e) { uvec2 v=add64(uvec2(stat[17],stat[18]),e); stat[17]=v.x;stat[18]=v.y; }
void consumed_atomic(uvec2 e) { uint old=atomicAdd(stat[17],e.x);uint high_add=e.y+uint(old+e.x<old);uint old_high=atomicAdd(stat[18],high_add);if(old_high+high_add>0x7fffffffu||old_high+high_add<old_high)atomicOr(stat[15],1u); }
uint hash32(uint x) { x^=x>>16; x*=0x7feb352du; x^=x>>15; x*=0x846ca68bu; return x^(x>>16); }
float random01(uint x) { return float(hash32(x)&0xffffffu)/16777216.0; }
vec2 normal_or(vec2 d,vec2 fallback) { float l=length(d);return l>0.00001?d/l:fallback; }
vec2 direction(float angle) { return vec2(cos(angle),sin(angle)); }
uint cell_index(vec2 pos) { ivec2 c=clamp(ivec2(pos/par[1].y),ivec2(0),ivec2(int(cols())-1));return uint(c.y)*cols()+uint(c.x); }
uint territory_index(vec2 pos) { ivec2 c=clamp(ivec2(pos/world()*float(terrain_size())),ivec2(0),ivec2(int(terrain_size())-1));return uint(c.y)*terrain_size()+uint(c.x); }
float shield_radius(uint t) { float e=value64(team[t].shield_gun.xy);return e<=0.0?0.0:min(world()*0.19,par[4].z*(par[8].z+(par[8].y-par[8].z)*sqrt(e/max(par[8].w,1.0)))); }
float ball_radius(uint i) { return clamp(par[5].x+par[5].y*sqrt(max(value64(energy(i))/max(p[i].geom.y,1.0),0.0)),par[5].x,par[5].z); }
float threshold() { return mix(par[6].x,par[6].y,clamp(pc.clock.y/max(par[6].z,0.001),0.0,1.0)); }
vec3 team_color(uint t) { if(t==0u)return vec3(1.0,0.22,0.32);if(t==1u)return vec3(0.18,1.0,0.51);if(t==2u)return vec3(0.22,0.5,1.0);return vec3(1.0,0.81,0.16); }
// 仅单invocation命令/事件pass调用；一次真正的归属变更同时维护两个面积计数。
void set_territory_owner(uint index,uint t) {uint previous=owner[index];if(previous==t)return;if(previous<4u)stat[8u+previous]--;owner[index]=t;if(t<4u)stat[8u+t]++;}
// invocation私有：一次prepare中只占槽、不释放槽；首次扫满后其余发射直接积压。
// 下一次dispatch重新初始化，碰撞腾出的槽会在下一子步正常重新使用。
bool normal_pool_exhausted=false;
bool big_pool_exhausted=false;
// 仅串行pass调用，物理容量不足时调用者保留原库存/命令，绝不吞弹药。
int free_slot(bool big) { uint start=big?cap():0u;uint count=big?balls():cap();uint cursor=big?stat[21]:stat[20];
 if(big?big_pool_exhausted:normal_pool_exhausted)return -1;
 for(uint n=0u;n<count;n++){uint i=start+(cursor+n)%count;if(p[i].info.w==0u){if(big)stat[21]=(cursor+n+1u)%count;else stat[20]=(cursor+n+1u)%count;return int(i);}}
 if(big)big_pool_exhausted=true;else normal_pool_exhausted=true;return -1; }
bool spawn(uint t,uint type,uvec2 e,float angle,uint seed) {
 int slot=free_slot(type==3u);if(slot<0)return false;uint i=uint(slot);float radius=type==3u?clamp(par[5].x+par[5].y*sqrt(value64(e)/max(threshold(),1.0)),par[5].x,par[5].z):par[4].x;
 vec2 d=direction(angle);float speed=type==3u?par[3].w:(type==2u?par[3].z:par[3].y);
 vec2 pos=team[t].core.xy+d*(max(team[t].core.z,shield_radius(t))+radius+3.0);pos=clamp(pos,vec2(radius+1.0),vec2(world()-radius-1.0));
 p[i].pv=vec4(pos,d*speed);p[i].info=uvec4(e,t,type);p[i].geom=vec4(radius,threshold(),pos);p[i].aux=uvec4(0u,seed,0u,0u);
 stat[16]++;if(e.y!=0u||e.x>1u)stat[14]++;return true;
}
void update_shields() { for(uint t=0u;t<4u;t++)team[t].core.w=shield_radius(t); }
void eliminate(uint t) {team[t].life.x=2u;team[t].life.z++;team[t].storm_sniper.xy=add64(team[t].storm_sniper.xy,team[t].shield_gun.zw);team[t].shield_gun.zw=uvec2(0u);team[t].shield_gun.xy=uvec2(0u);}
void resolve_rescue(Command c) {uint t=c.a.y;if(t>=4u||team[t].life.x!=1u||team[t].life.y!=c.b.y)return;
 if(!zero64(c.a.zw)){team[t].shield_gun.xy=add64(team[t].shield_gun.xy,c.a.zw);team[t].clocks.x=pc.clock.y+par[4].w;team[t].life.x=0u;}
 else if(!zero64(team[t].shield_gun.xy))team[t].life.x=0u; // 握手期间正常充盾也必须保护核心。
 else eliminate(t);}
bool execute_command(Command c) {uint op=c.a.x;uint t=c.a.y;if(op==0u)return true;if(op==6u){resolve_rescue(c);return true;}
 // 批内较晚落槽的武器只在对应模拟步生效；负时间保留测试/死亡余波的立即语义。
 if(op>=1u&&op<=5u){float at_time=uintBitsToFloat(c.b.w);if(at_time>=0.0&&pc.clock.y+0.00001<at_time)return false;}
 // 独立测试入口：正常UI不会提交10..16号命令。所有修改仍在GPU内完成。
 if(op==14u){for(uint i=0u;i<total();i++)p[i].info.w=0u;stat[20]=0u;stat[21]=0u;normal_pool_exhausted=false;big_pool_exhausted=false;return true;}
 if(op==15u){uint n=max(c.b.x,1u);for(uint k=0u;k<n&&c.a.z+k<terrain_size()*terrain_size();k++)set_territory_owner(c.a.z+k,t);return true;}
 if(op==16u){for(uint i=0u;i<terrain_size()*terrain_size();i++)owner[i]=t;for(uint k=0u;k<4u;k++)stat[8u+k]=k==t?terrain_size()*terrain_size():0u;return true;}
 if(t>=4u)return true;
 if(op==17u){uint width=uint(ceil(sqrt(float(cap()))));float spacing=world()/float(width);vec2 velocity=uintBitsToFloat(c.b.xy);if(dot(velocity,velocity)<0.00001)velocity=vec2(30.0,17.0);
  for(uint i=0u;i<cap();i++){vec2 position=(vec2(i%width,i/width)+0.5)*spacing;position=clamp(position,vec2(par[4].x),vec2(world()-par[4].x));p[i].pv=vec4(position,velocity);p[i].info=uvec4(1u,0u,t,1u);p[i].geom=vec4(par[4].x,threshold(),position);p[i].aux=uvec4(0u,hash32(i),0u,0u);}stat[20]=0u;return true;}
 if(op==10u){team[t].shield_gun=uvec4(c.a.zw,c.b.xy);team[t].life.x=c.b.z;team[t].clocks.x=uintBitsToFloat(c.b.w);team[t].storm_sniper=uvec4(0u);return true;}
 if(op>=11u&&op<=13u){int slot=free_slot(op==13u);if(slot<0)return false;uint i=uint(slot);uint ty=op==11u?1u:(op==12u?2u:3u);p[i].pv=uintBitsToFloat(c.b);p[i].info=uvec4(c.a.zw,t,ty);p[i].geom=vec4(ty==3u?par[5].x:par[4].x,threshold(),p[i].pv.xy);p[i].aux=uvec4(0u,hash32(i+stat[7]),0u,0u);if(ty==3u)p[i].geom.x=ball_radius(i);return true;}
 // 淘汰后只允许带明确死亡余波标记的大球；异步通知到达前的普通输出不能继续生产。
 if(op>=1u&&op<=5u&&team[t].life.x==2u&&!(op==2u&&(c.b.z&1u)!=0u)){stat[28]++;return true;}
 if(op==1u){if(team[t].life.x!=2u){if(!can_add64(team[t].shield_gun.xy,c.a.zw)){atomicOr(stat[15],1u);return false;}team[t].shield_gun.xy=add64(team[t].shield_gun.xy,c.a.zw);}return true;}
 if(op==2u)return spawn(t,3u,c.a.zw,random01(c.b.x+stat[7]+t*241u+uint(par[0].w))*TAU,c.b.x);
 if(op==3u){if(!zero64(team[t].storm_sniper.zw))return false;team[t].storm_sniper.zw=c.a.zw;team[t].misc.x=floatBitsToUint(random01(c.b.x+stat[7]+t*37u+uint(par[0].w))*TAU);return true;}
 if(op==4u){uvec2 reserve=add64(team[t].storm_sniper.xy,team[t].shield_gun.zw);if(!can_add64(reserve,c.a.zw)){atomicOr(stat[15],1u);return false;}team[t].storm_sniper.xy=add64(team[t].storm_sniper.xy,c.a.zw);return true;}
 if(op==5u){if(team[t].life.x!=2u){uvec2 reserve=add64(team[t].storm_sniper.xy,team[t].shield_gun.zw);if(!can_add64(reserve,c.a.zw)){atomicOr(stat[15],1u);return false;}team[t].shield_gun.zw=add64(team[t].shield_gun.zw,c.a.zw);}return true;}
 return true;
}
float gun_aim(uint t,uint shot) {float angle=team[t].clocks.z; // 保持连续旋转，最多1/4射击按领土缺口偏转，避免锁死。
 if((shot&7u)==0u){float nearest=world()*0.24;int target=-1;for(uint b=cap();b<total();b++)if(p[b].info.w==3u&&p[b].info.z!=t){float dist=distance(p[b].pv.xy,team[t].core.xy)-p[b].geom.x;if(dist<nearest){nearest=dist;target=int(b);}}if(target>=0){vec2 aim=p[uint(target)].pv.xy-team[t].core.xy;return atan(aim.y,aim.x);}}
 if((shot&3u)!=0u)return angle;float best=-1e9;float result=angle;
 for(uint k=0u;k<8u;k++){float a=angle+float(k)*TAU/8.0;float score=0.0;for(uint d=1u;d<=4u;d++){vec2 q=team[t].core.xy+direction(a)*float(d)*world()*0.09;if(any(lessThan(q,vec2(0)))||any(greaterThan(q,vec2(world()))))continue;score+=owner[territory_index(q)]==t?0.0:1.0/float(d);}
 score+=0.15*cos(a-angle);if(score>best){best=score;result=a;}}return result;
}
void prepare() {
 for(uint n=1028u;n<1036u;n++){Command c=command[n];if(c.a.x!=0u&&execute_command(c))command[n].a.x=0u;}
 for(uint t=0u;t<4u;t++){Command c=command[1024u+t];if(c.a.x==6u)resolve_rescue(c);command[1024u+t].a.x=0u;}
 uint command_head=stat[4];uint queued=pc.control.z-command_head;uint pending_count=0u;uvec2 pending_energy=uvec2(0u);
 // 有容量的命令可以越过等待中的大球/狙击命令；只连续回收已确认完成的前缀。
 // 因此别队的护盾充能不会被单一拥堵武器挡住，CPU仍用head保证环槽不覆写。
 for(uint n=0u;n<min(queued,1024u);n++){uint slot=(command_head+n)%1024u;Command c=command[slot];if(c.a.x!=0u){if(execute_command(c))command[slot].a.x=0u;else {pending_count++;if(c.a.x<=5u)pending_energy=add64(pending_energy,c.a.zw);}}}
 while(command_head!=pc.control.z&&command[command_head%1024u].a.x==0u)command_head++;
 stat[4]=command_head;stat[5]=pending_count;stat[25]=pending_energy.x;stat[26]=pending_energy.y;stat[27]=pc.control.z-command_head;
 update_shields();uint budget=uint(par[6].w);uint packet=max(1u,uint(par[4].y));
 for(uint order=0u;order<4u;order++){uint t=(order+stat[7])%4u;
  team[t].clocks.z=mod(team[t].clocks.z+pc.clock.x*1.7,TAU);
  if(team[t].life.x!=2u){float rate=mix(par[2].z,par[2].w,clamp(pc.clock.y/max(par[3].x,0.001),0.0,1.0));team[t].clocks.y=min(team[t].clocks.y+rate*pc.clock.x,rate*2.0+1.0);}
  for(uint kind=0u;kind<3u;kind++){uint shot=0u;while(budget>0u){uvec2 available=kind==0u?team[t].shield_gun.zw:(kind==1u?team[t].storm_sniper.xy:team[t].storm_sniper.zw);if(zero64(available))break;
    if(kind==0u&&(team[t].life.x==2u||team[t].clocks.y<1.0))break;
    uint amount=packet;if(kind==0u)amount=min(amount,uint(floor(team[t].clocks.y)));uvec2 e=min64(available,uvec2(amount,0u));
    float angle=kind==0u?gun_aim(t,team[t].accounting.x):(kind==1u?team[t].clocks.w:uintBitsToFloat(team[t].misc.x)+(random01(shot+stat[7])-0.5)*0.026);
    if(!spawn(t,kind==2u?2u:1u,e,angle,hash32(stat[7]*192u+budget)))break;
    if(kind==0u){team[t].shield_gun.zw=sub64(available,e);team[t].clocks.y-=float(e.x);team[t].clocks.z=mod(team[t].clocks.z+0.19,TAU);team[t].accounting.x++;}
    else if(kind==1u){team[t].storm_sniper.xy=sub64(available,e);team[t].clocks.w=mod(team[t].clocks.w+2.39996323,TAU);}
    else team[t].storm_sniper.zw=sub64(available,e);
    budget--;shot++;if(shot>=uint(par[6].w)/4u)break;
  }}
 }stat[7]++;stat[19]=floatBitsToUint(pc.clock.y);
}
void initialize(uint i) {
 if(i<total()){p[i].pv=vec4(0.0);p[i].info=uvec4(0u);p[i].geom=vec4(0.0);p[i].aux=uvec4(0u);}
 if(i<cols()*cols())head[i]=-1;if(i<cap())next_id[i]=-1;
 if(i<terrain_size()*terrain_size()){uint x=i%terrain_size(),y=i/terrain_size();owner[i]=(x>=terrain_size()/2u?1u:0u)+(y>=terrain_size()/2u?2u:0u);}
 if(i<render_size()*render_size())pixels[i]=0u;if(i<64u){stat[i]=0u;if(i>=8u&&i<12u){uint t=i-8u;uint half_n=terrain_size()/2u;uint width=(t&1u)!=0u?terrain_size()-half_n:half_n;uint height=(t&2u)!=0u?terrain_size()-half_n:half_n;stat[i]=width*height;}}
 if(i<1036u){command[i].a=uvec4(0u);command[i].b=uvec4(0u);}
 if(i<4u){team[i].shield_gun=floatBitsToUint(par[9]);team[i].storm_sniper=uvec4(0u);team[i].life=uvec4(0u);team[i].clocks=vec4(0.0,0.0,float(i)*TAU/4.0,0.0);team[i].accounting=uvec4(0u);team[i].core=vec4(vec2((i&1u)!=0u?0.75:0.25,(i&2u)!=0u?0.75:0.25)*world(),par[5].w,par[8].y*par[4].z);team[i].core.w=shield_radius(i);team[i].misc=uvec4(0u);team[i].visual=vec4(0u);}
}
void move_particle(uint i) {if(i>=total()||p[i].info.w==0u)return;float r=p[i].info.w==3u?ball_radius(i):par[4].x;p[i].geom.x=r;p[i].geom.zw=p[i].pv.xy;
 vec2 pos=p[i].pv.xy+p[i].pv.zw*pc.clock.x;vec2 vel=p[i].pv.zw; // 有限步长反射，保持撞墙后真实位置在边界内。
 for(int axis=0;axis<2;axis++){if(pos[axis]<r){pos[axis]=2.0*r-pos[axis];vel[axis]=abs(vel[axis]);}if(pos[axis]>world()-r){pos[axis]=2.0*(world()-r)-pos[axis];vel[axis]=-abs(vel[axis]);}}
 p[i].pv=vec4(clamp(pos,vec2(r),vec2(world()-r)),vel);
 for(uint t=0u;t<4u;t++){float distance_core=distance(p[i].pv.xy,team[t].core.xy);if(distance_core>team[t].core.w+r+2.0)p[i].aux.x&=~(1u<<t);
  // 保命请求对应的攻击在握手期间保持接触保护，补盾后须先离开新护盾才可重新结算。
  if(team[t].life.x==2u||(team[t].life.x==0u&&distance_core>team[t].core.w+r+2.0))p[i].aux.z&=~(1u<<t);}
}
void build_space(uint i) {if(i>=cap()||p[i].info.w==0u)return;uint c=cell_index(p[i].pv.xy);next_id[i]=atomicExchange(head[c],int(i));}
// 9色中心格的3×3邻域互不相交，单线程负责一个中心格，故没有两个线程修改同一粒子。
// 链表遍历直到-1，不存在32/64粒子截断。pair按索引排序只结算一次。
void resolve_pair(uint a,uint b) {if(p[a].info.w==0u||p[b].info.w==0u)return;vec2 d=p[b].pv.xy-p[a].pv.xy;float rr=p[a].geom.x+p[b].geom.x;float d2=dot(d,d);
 if(d2>=rr*rr){vec2 old=p[b].geom.zw-p[a].geom.zw;vec2 rel=d-old;float dd=dot(rel,rel);float time=dd>0.00001?clamp(-dot(old,rel)/dd,0.0,1.0):1.0;vec2 near=old+rel*time;if(dot(near,near)>=rr*rr)return;d=dot(near,near)>0.000001?near:normal_or(old,vec2(1,0))*0.0001;d2=dot(d,d);}
 atomicAdd(stat[2],1u);vec2 n=normal_or(d,direction(float((a*31u+b*17u)%628u)*0.01));float separation=max(rr-sqrt(d2),0.0)*0.5+0.001;
 p[a].pv.xy-=n*separation;p[b].pv.xy+=n*separation;
 if(p[a].info.z!=p[b].info.z){uvec2 cancel=min64(energy(a),energy(b));spend(a,cancel);spend(b,cancel);consumed_atomic(cancel);consumed_atomic(cancel);return;}
 float ma=max(value64(energy(a)),1.0),mb=max(value64(energy(b)),1.0);float rel=dot(p[b].pv.zw-p[a].pv.zw,n);if(rel<0.0){float impulse=-2.0*rel/(1.0/ma+1.0/mb);p[a].pv.zw-=impulse/ma*n;p[b].pv.zw+=impulse/mb*n;}
 if(p[a].info.w==2u)p[a].pv.zw+=vec2(-n.y,n.x)*0.8;if(p[b].info.w==2u)p[b].pv.zw-=vec2(-n.y,n.x)*0.8;
}
void collision_cell(uint index) {uvec2 offset=uvec2(pc.control.y%3u,pc.control.y/3u);uint phase_width=(cols()-offset.x+2u)/3u;
 uint cx=(index%phase_width)*3u+offset.x,cy=(index/phase_width)*3u+offset.y;if(cx>=cols()||cy>=cols())return;uint c=cy*cols()+cx;
 int a=head[c];uint occupancy=0u;while(a>=0){occupancy++;uint ai=uint(a);for(int dy=-1;dy<=1;dy++)for(int dx=-1;dx<=1;dx++){ivec2 q=ivec2(cx,cy)+ivec2(dx,dy);if(any(lessThan(q,ivec2(0)))||any(greaterThanEqual(q,ivec2(cols()))))continue;int b=head[uint(q.y)*cols()+uint(q.x)];while(b>=0){if(uint(b)>ai)resolve_pair(ai,uint(b));b=next_id[uint(b)];}}a=next_id[ai];}atomicMax(stat[6],occupancy);
}
// 以下事件由单GPU invocation顺序处理。它是显式性能取舍，不是CPU物理；避免领土/护盾多写竞态。
bool swept_hit(vec2 from,vec2 to,vec2 center,float radius,out float hit_t,out vec2 hit_normal) {vec2 d=to-from;vec2 m=from-center;float c=dot(m,m)-radius*radius;
 if(c<=0.0){hit_t=0.0;hit_normal=normal_or(m,vec2(1,0));return true;}float a=dot(d,d);if(a<1e-9)return false;float b=dot(m,d);float disc=b*b-a*c;if(disc<0.0)return false;float t=(-b-sqrt(disc))/a;if(t<0.0||t>1.0)return false;hit_t=t;hit_normal=normal_or(from+d*t-center,vec2(1,0));return true;}
void reflect_contact(uint i,vec2 center,float radius,vec2 n) {p[i].pv.xy=center+n*(radius+0.08);if(dot(p[i].pv.zw,n)<0.0)p[i].pv.zw=reflect(p[i].pv.zw,n);}
void terrain_events(uint i);
void shield_core_events(uint i) {if(p[i].info.w==0u)return;uint own=p[i].info.z;int target=-1;float first_time=2.0;vec2 normal=vec2(1,0);float target_radius=0.0;bool target_shield=false;
 // 先找到整条运动段最早的实体接触，再把领土扫描截断至接触点。
 // 路上已经耗尽的粒子绝不可能隔空伤盾或触发核心事件。
 for(uint t=0u;t<4u;t++){if(t==own||team[t].life.x==2u)continue;bool shield=!zero64(team[t].shield_gun.xy);float radius=shield?shield_radius(t):team[t].core.z;float hit_t;vec2 hit_normal;
  if(swept_hit(p[i].geom.zw,p[i].pv.xy,team[t].core.xy,radius+p[i].geom.x,hit_t,hit_normal)&&hit_t<first_time){target=int(t);first_time=hit_t;normal=hit_normal;target_radius=radius;target_shield=shield;}}
 if(target>=0)p[i].pv.xy=mix(p[i].geom.zw,p[i].pv.xy,first_time);
 terrain_events(i);if(target<0||p[i].info.w==0u)return;
 uint t=uint(target);reflect_contact(i,team[t].core.xy,target_radius+p[i].geom.x,normal);
 if(target_shield){if((p[i].aux.z&(1u<<t))!=0u){p[i].aux.z&=~(1u<<t);p[i].aux.x|=1u<<t;return;}
  if((p[i].aux.x&(1u<<t))==0u){uvec2 cancel=min64(energy(i),team[t].shield_gun.xy);team[t].shield_gun.xy=sub64(team[t].shield_gun.xy,cancel);spend(i,cancel);consumed(cancel);p[i].aux.x|=1u<<t;}return;}
 // 同一接触只走盾或核心中的一条出口；PENDING_RESCUE提供事件保护。
 if(team[t].life.x==0u){if(pc.clock.y+0.000001<team[t].clocks.x)eliminate(t);else {team[t].life.x=1u;team[t].life.y++;team[t].misc.z=p[i].info.x;team[t].misc.w=p[i].info.y;}}
 if(team[t].life.x==1u)p[i].aux.z|=1u<<t;
}
void particle_ball_pair(uint a,uint b) {if(p[a].info.w==0u||p[b].info.w==0u)return;float time;vec2 n;float r=p[a].geom.x+p[b].geom.x;vec2 relative_from=p[a].geom.zw-p[b].geom.zw,relative_to=p[a].pv.xy-p[b].pv.xy;
 if(!swept_hit(relative_from,relative_to,vec2(0),r,time,n))return;stat[2]++;
 float ma=max(value64(energy(a)),1.0),mb=max(value64(energy(b)),1.0);float rel=dot(p[a].pv.zw-p[b].pv.zw,n);
 if(rel<0.0){float impulse=-2.0*rel/(1.0/ma+1.0/mb);p[a].pv.zw+=impulse/ma*n;p[b].pv.zw-=impulse/mb*n;}
 vec2 mid=(p[a].pv.xy+p[b].pv.xy)*0.5;float overlap=max(r-distance(p[a].pv.xy,p[b].pv.xy),0.0)+0.02;p[a].pv.xy+=n*overlap*mb/(ma+mb);p[b].pv.xy-=n*overlap*ma/(ma+mb);
 if(p[a].info.z!=p[b].info.z){uvec2 cancel=min64(energy(a),energy(b));spend(a,cancel);spend(b,cancel);consumed(cancel);consumed(cancel);}
}
void claim(uint i,uint index) {if(p[i].info.w==0u||owner[index]==p[i].info.z)return;set_territory_owner(index,p[i].info.z);spend(i,uvec2(1u,0u));stat[3]++;consumed(uvec2(1u,0u));}
void terrain_events(uint i) {if(p[i].info.w==0u)return;uint n=terrain_size();float unit=world()/float(n);vec2 a=p[i].geom.zw,b=p[i].pv.xy;
 if(p[i].info.w!=3u){
  // Amanatides/Woo DDA：精确遍历中心轨迹真正经过的每一格，无采样跳格或固定次数截断。
  ivec2 cell=clamp(ivec2(floor(a/unit)),ivec2(0),ivec2(int(n)-1));ivec2 last=clamp(ivec2(floor(b/unit)),ivec2(0),ivec2(int(n)-1));vec2 ray=b-a;ivec2 step_dir=ivec2(sign(ray));vec2 t_delta=vec2(1e30),t_max=vec2(1e30);
  for(int axis=0;axis<2;axis++)if(abs(ray[axis])>0.0000001){t_delta[axis]=abs(unit/ray[axis]);float boundary=float(cell[axis]+(step_dir[axis]>0?1:0))*unit;t_max[axis]=(boundary-a[axis])/ray[axis];}
  claim(i,uint(cell.y)*n+uint(cell.x));if(p[i].info.w==0u){p[i].pv.xy=a;return;}
  while(any(notEqual(cell,last))&&p[i].info.w!=0u){float crossing=min(t_max.x,t_max.y);bool step_x=t_max.x<=t_max.y;bool step_y=t_max.y<=t_max.x;
   if(step_x){cell.x+=step_dir.x;t_max.x+=t_delta.x;}if(step_y){cell.y+=step_dir.y;t_max.y+=t_delta.y;}
   if(any(lessThan(cell,ivec2(0)))||any(greaterThanEqual(cell,ivec2(n))))break;claim(i,uint(cell.y)*n+uint(cell.x));if(p[i].info.w==0u)p[i].pv.xy=mix(a,b,clamp(crossing+0.000001,0.0,1.0));
  }return;
 }
 // 大球扫掠胶囊逐格占领；每一个真正改变归属的格子严格扣1，重叠扫掠不会重复扣。
 float radius=p[i].geom.x;ivec2 low=clamp(ivec2(floor((min(a,b)-vec2(radius))/unit)),ivec2(0),ivec2(int(n)-1));ivec2 high=clamp(ivec2(ceil((max(a,b)+vec2(radius))/unit)),ivec2(0),ivec2(int(n)-1));vec2 d=b-a;float dd=dot(d,d);
 for(int y=low.y;y<=high.y&&p[i].info.w!=0u;y++)for(int x=low.x;x<=high.x&&p[i].info.w!=0u;x++){vec2 point=(vec2(x,y)+0.5)*unit;float t=dd>0.000001?clamp(dot(point-a,d)/dd,0.0,1.0):0.0;if(distance(point,a+d*t)<=radius)claim(i,uint(y)*n+uint(x));}
 if(p[i].info.w!=0u)p[i].geom.x=ball_radius(i);
}
void events() {
 // ID升序快照保留原结算顺序。这里不会新生大球；被前一接触消灭的球仍由pair检查跳过。
 // 无大球时直接跳过normal×64；有少量大球时只遍历实际ID，不反复读空槽。
 // 两个uint掩码避免每个线程携带64项私有数组及其寄存器/本地内存开销。
 uvec2 active_balls=uvec2(0u);
 for(uint b=0u;b<balls();b++)if(p[cap()+b].info.w==3u)active_balls[b/32u]|=1u<<(b%32u);
 for(uint aw=0u;aw<2u;aw++){uint remaining_a=active_balls[aw];while(remaining_a!=0u){uint a=cap()+aw*32u+uint(findLSB(remaining_a));remaining_a&=remaining_a-1u;
  if(p[a].info.w==3u)for(uint bw=aw;bw<2u;bw++){uint remaining_b=bw==aw?remaining_a:active_balls[bw];while(remaining_b!=0u){uint b=cap()+bw*32u+uint(findLSB(remaining_b));remaining_b&=remaining_b-1u;if(p[b].info.w==3u)particle_ball_pair(a,b);}}
 }}
 if(any(notEqual(active_balls,uvec2(0u))))for(uint a=0u;a<cap();a++)if(p[a].info.w!=0u)for(uint bw=0u;bw<2u;bw++){uint remaining_b=active_balls[bw];while(remaining_b!=0u){uint b=cap()+bw*32u+uint(findLSB(remaining_b));remaining_b&=remaining_b-1u;if(p[b].info.w==3u)particle_ball_pair(a,b);}}
 for(uint i=0u;i<total();i++)if(p[i].info.w!=0u)shield_core_events(i);update_shields();
}
void statistics() {
 stat[0]=0u;stat[1]=0u;stat[12]=0u;stat[13]=0u;stat[22]=0u;uvec2 normal_energy=uvec2(0u);
 for(uint i=0u;i<total();i++)if(p[i].info.w!=0u){if(p[i].info.w==3u)stat[1]++;else {stat[0]++;if(p[i].info.y!=0u||p[i].info.x>1u)stat[22]++;normal_energy=add64(normal_energy,energy(i));}}
 stat[23]=normal_energy.x;stat[24]=normal_energy.y;
 for(uint t=0u;t<4u;t++){if(team[t].life.x==1u)stat[12]|=1u<<t;if(team[t].life.x==2u)stat[13]|=1u<<t;}
 // stat[8..11]由初始化/claim/显式调试染色精确维护；这里不再扫描512²地图。
}
void splat(uint i) {if(i>=total()||p[i].info.w==0u)return;if(p[i].info.w!=3u&&random01(i)>par[7].z)return;
 uint n=render_size();float scale=float(n)/world();vec2 a=p[i].geom.zw*scale,b=p[i].pv.xy*scale;float r=max(p[i].info.w==3u?p[i].geom.x*scale:par[7].x*scale,0.8);vec2 d=b-a;float dd=dot(d,d);a=mix(b,a,clamp(par[7].y,0.0,1.0));
 ivec2 lo=max(ivec2(0),ivec2(floor(min(a,b)-r-1.0)));ivec2 hi=min(ivec2(int(n)-1),ivec2(ceil(max(a,b)+r+1.0)));uint color=p[i].info.z+1u;
 for(int y=lo.y;y<=hi.y;y++)for(int x=lo.x;x<=hi.x;x++){vec2 q=vec2(x,y)+0.5;float t=dd>0.0001?clamp(dot(q-a,b-a)/max(dot(b-a,b-a),0.0001),0.0,1.0):1.0;float dist=distance(q,mix(a,b,t));if(dist<=r){uint bright=uint(clamp(1.0-dist/max(r,0.1),0.0,1.0)*255.0);uint packed=(p[i].info.w==3u?0x1000000u:0u)|(bright<<8)|color;atomicMax(pixels[uint(y)*n+uint(x)],packed);}}
}
void render(uint i) {uint n=render_size();if(i>=n*n)return;uint x=i%n,y=i/n;vec2 q=(vec2(x,y)+0.5)/float(n)*world();uint t=owner[territory_index(q)];vec3 c=t<4u?team_color(t)*0.22:vec3(0.07,0.09,0.13);
 uint tn=terrain_size();ivec2 tp=clamp(ivec2(q/world()*float(tn)),ivec2(0),ivec2(int(tn)-1));if(tp.x<int(tn)-1&&owner[uint(tp.y)*tn+uint(tp.x)+1u]!=t)c*=1.35;if(tp.y<int(tn)-1&&owner[(uint(tp.y)+1u)*tn+uint(tp.x)]!=t)c*=1.35;
 for(uint k=0u;k<4u;k++){if(team[k].life.x==2u)continue;float distance_core=distance(q,team[k].core.xy);float shield=team[k].core.w;
 if(shield>0.0){float ring=1.0-smoothstep(0.6,2.0,abs(distance_core-shield));c=mix(c,team_color(k)*0.9,ring*0.8);if(distance_core<shield)c+=team_color(k)*0.018;}
 if(distance_core<team[k].core.z){float glow=1.0-distance_core/team[k].core.z;c=team_color(k)*(0.75+0.5*glow);if(team[k].life.x==1u)c=mix(c,vec3(1),0.35+0.25*sin(pc.clock.y*15.0));}
 vec2 gun=team[k].core.xy+direction(team[k].clocks.z)*(team[k].core.z+4.0);if(distance(q,gun)<3.0)c=vec3(1.0);
 }
 uint packed=pixels[i];if(packed!=0u){uint color=(packed&255u)-1u;float bright=float((packed>>8)&255u)/255.0;bool big=(packed&0x1000000u)!=0u;vec3 tint=team_color(color);c=big?mix(tint*0.45,vec3(1),bright*0.60):mix(tint,vec3(1),bright*0.65);}
 float edge=min(min(q.x,q.y),min(world()-q.x,world()-q.y));if(edge<2.0)c=vec3(0.43,0.58,0.73);imageStore(output_image,ivec2(x,y),vec4(clamp(c,0.0,1.0),1.0));
}
void main(){uint i=gl_GlobalInvocationID.x;uint mode=pc.control.x;
 if(mode==0u)initialize(i);else if(mode==1u){if(i==0u)prepare();}else if(mode==2u)move_particle(i);else if(mode==3u){if(i<cols()*cols())head[i]=-1;}else if(mode==4u)build_space(i);else if(mode==5u)collision_cell(i);else if(mode==6u){if(i==0u)events();}else if(mode==7u){if(i==0u)statistics();}else if(mode==8u){if(i<render_size()*render_size())pixels[i]=0u;}else if(mode==9u)splat(i);else if(mode==10u)render(i);
}
