class_name AirCurtain
extends RefCounted

var strength: float = 2950.0
var width: float = 96.0
var height: float = 180.0
var top: float = 286.0
var reference_radius: float = 4.2
var response_power: float = 2.8
var spread: float = 310.0

func configure(settings: Dictionary) -> void:
	strength = maxf(0.0, float(settings.get("air_force", strength)))
	width = clampf(float(settings.get("air_width", width)), 16.0, 98.0)
	height = clampf(float(settings.get("air_height", height)), 40.0, 280.0)
	top = 466.0 - height
	reference_radius = maxf(1.0, float(settings.get("radius_min", reference_radius)))
	response_power = clampf(float(settings.get("air_response_power", settings.get("air_exponent", response_power))), 0.2, 8.0)
	spread = maxf(0.0, float(settings.get("air_spread", spread)))

func acceleration(position: Vector2, radius: float) -> Vector2:
	var half_width: float = width * 0.5
	if absf(position.x - 240.0) > half_width or position.y < top or position.y > top + height:
		return Vector2.ZERO
	# 气流只读物理半径。这里既不读取弹药数值，也不读取出生门槛。
	var response: float = pow(reference_radius / maxf(reference_radius, radius), response_power)
	# 上端向两边散开的连续流场，防止中央形成稳定悬浮堆；不是随机放行。
	var side: float = (position.x - 240.0) / half_width
	return Vector2(side * spread * response, -strength * response)

func draw_on(canvas: Node2D, simulation_time: float) -> void:
	var left: float = 240.0 - width * 0.5
	canvas.draw_rect(Rect2(left, top, width, height), Color(0.18, 0.64, 0.91, 0.055))
	for index in range(11):
		var x: float = left + (float(index) + 0.5) * width / 11.0
		var y: float = top + fposmod(float(index) * 41.0 - simulation_time * 180.0, height)
		var alpha: float = 0.25 + 0.16 * sin(float(index) * 2.0)
		var tone: Color = Color(0.32, 0.8, 1.0, alpha)
		canvas.draw_line(Vector2(x, minf(y + 15.0, top + height)), Vector2(x, y), tone, 1.3)
		canvas.draw_line(Vector2(x - 2.5, y + 5.0), Vector2(x, y), tone, 1.3)
		canvas.draw_line(Vector2(x + 2.5, y + 5.0), Vector2(x, y), tone, 1.3)

func snapshot() -> Dictionary:
	return {"strength": strength, "width": width, "height": height, "top": top, "response_power": response_power}
