extends Node2D
## 主控只推进固定时间、16颗弹药球和UI。右侧实体没有CPU逐粒子循环。

const BATTLE_RECT := Rect2(530, 112, 850, 850)
var settings: Dictionary = {}
var pinball: PinballPhysics
var world: GPUWorld
var ui: GameUI
var battle_view: TextureRect
var labels: BattleLabels
var active_dt := 1.0 / 120.0
var elapsed := 0.0
var accumulator := 0.0
var paused := false
var one_step := false
var status_clock := 0.0
var generation := 0
var retired: Array[GPUWorld] = []
var trigger_history: Array[Dictionary] = []
var first_texture := false
var font: Font

func _ready() -> void:
	font = ThemeDB.fallback_font
	if ResourceLoader.exists("res://assets/chinese_ui.otf"):
		font = load("res://assets/chinese_ui.otf")
	settings = GameSettings.load_file()
	battle_view = TextureRect.new()
	battle_view.position = BATTLE_RECT.position
	battle_view.size = BATTLE_RECT.size
	battle_view.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	battle_view.stretch_mode = TextureRect.STRETCH_SCALE
	battle_view.mouse_filter = Control.MOUSE_FILTER_IGNORE
	battle_view.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	add_child(battle_view)
	labels = BattleLabels.new()
	labels.font = font
	add_child(labels)
	pinball = PinballPhysics.new()
	pinball.font = font
	pinball.position = Vector2(22, 112)
	add_child(pinball)
	pinball.weapon_output.connect(_weapon_output)
	pinball.trigger_log.connect(_trigger_log)
	pinball.simulation_fault.connect(func(message: String):
		paused = true
		push_error(message)
	)
	ui = GameUI.new()
	add_child(ui)
	ui.setup(settings)
	ui.pause_pressed.connect(func(): paused = not paused)
	ui.step_pressed.connect(func(): paused = true; one_step = true)
	ui.restart_pressed.connect(_restart)
	ui.speed_changed.connect(func(value: float): settings["time_scale"] = value)
	ui.settings_changed.connect(_settings_changed)
	ui.debug_requested.connect(_debug_requested)
	get_tree().auto_accept_quit = false
	_restart()

func _restart() -> void:
	generation += 1
	if world != null:
		world.shutdown()
		# RD释放排在渲染线程队列；延后回收节点，让小表异步回调先完成。
		retired.append(world)
		world.set_process(false)
		_dispose_retired(world)
	world = GPUWorld.new()
	add_child(world)
	world.configure(settings)
	var current_generation := generation
	world.initialized.connect(func():
		if current_generation == generation:
			battle_view.texture = world.texture
			first_texture = true
			print("运行：GPU共享纹理已绑定，未使用整帧CPU回读。")
	)
	world.failed.connect(func(message: String):
		if current_generation == generation:
			paused = true
			push_error("战场停止：" + message)
	)
	world.rescue_requested.connect(func(team: int):
		if current_generation != generation: return
		var energy := pinball.rescue(team)
		world.resolve_rescue(team, energy)
		print("紧急保命：阵营%d，球能量 %.0f，模拟时间 %.3f" % [team, energy, elapsed])
	)
	world.team_eliminated.connect(func(team: int):
		if current_generation != generation: return
		var values := pinball.eliminate(team)
		world.death_balls(team, values)
		print("确认淘汰：阵营%d，余波球数%d，模拟时间 %.3f" % [team, values.size(), elapsed])
	)
	elapsed = 0.0
	active_dt = float(settings.get("fixed_dt", 1.0 / 120.0))
	labels.stats = {}
	accumulator = 0.0
	paused = false
	one_step = false
	first_texture = false
	battle_view.texture = null
	trigger_history.clear()
	settings["font"] = font
	pinball.configure(settings)
	pinball.reset(int(settings.get("seed", 20261016)))
	Engine.max_fps = int(settings.get("fps_limit", 60))
	world.start()
	queue_redraw()

func _dispose_retired(old: GPUWorld) -> void:
	# Godot异步读回通常延后数个渲染帧；保留8帧后移除空壳，避免每次重开累积Node。
	for index in 8:
		await get_tree().process_frame
	if is_instance_valid(old) and old != world:
		retired.erase(old)
		old.queue_free()

func _process(delta: float) -> void:
	if world == null: return
	if not pinball.error.is_empty():
		paused = true
		one_step = false
	if world.active and pinball.error.is_empty():
		var dt := active_dt
		if not paused:
			accumulator += delta * float(settings.get("time_scale", 0.25))
		var steps := 0
		while ((not paused and accumulator >= dt) or one_step) and steps < 8:
			elapsed += dt
			pinball.step(dt, elapsed)
			if not pinball.error.is_empty():
				one_step = false
				break
			world.step(dt, elapsed)
			if one_step:
				one_step = false
				break
			accumulator -= dt
			steps += 1
		# 超负荷时保留积压，绝不把时间/伤害/弹药静默丢弃。
		world.flush()
	labels.stats = world.stats
	labels.queue_redraw()
	status_clock += delta
	if status_clock >= 0.10:
		status_clock = 0.0
		ui.update_state({"sim_time": elapsed, "paused": paused,
			"fixed_dt": active_dt, "fps": Engine.get_frames_per_second(), "gpu_active": world.active,
			"error": pinball.error if not pinball.error.is_empty() else world.error_message, "stats": world.stats,
			"pinball": pinball.snapshot(), "time_backlog": accumulator,
			"settings": settings})
	queue_redraw()

func _weapon_output(team: int, kind: int, energy: float) -> void:
	if world != null: world.output(team, kind, energy, elapsed)

func _trigger_log(data: Dictionary) -> void:
	trigger_history.append(data)
	if trigger_history.size() > 256: trigger_history.pop_front()

func _settings_changed(config: Dictionary) -> void:
	var previous := settings
	settings = GameSettings.validate(config)
	settings["font"] = font
	pinball.configure(settings)
	Engine.max_fps = int(settings.get("fps_limit", 60))
	if world != null and world.has_method("update_settings"):
		world.call("update_settings", settings)
	# 容量、地图精度和输出纹理在面板标明新开局生效；此处不隐式重建。
	if float(previous.get("time_scale", 0.25)) != float(settings.get("time_scale", 0.25)):
		accumulator = 0.0

func _debug_requested(kind: String) -> void:
	if world == null: return
	if kind == "screenshot":
		await RenderingServer.frame_post_draw
		var path := "user://截图_%d.png" % Time.get_unix_time_from_system()
		var error := get_viewport().get_texture().get_image().save_png(path)
		print("截图：", ProjectSettings.globalize_path(path), " 状态：", error)
	elif kind == "storm":
		world.output(0, 3, 10000.0)
	elif kind == "sniper":
		world.output(0, 2, 10000.0)
	elif kind == "big_ball":
		# 明示调试发射，非正式规则后台抽取。
		world.output(0, 1, 100000.0)
	else:
		print("调试快照：", world.debug_readback(kind))

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_SPACE: paused = not paused
			KEY_N: paused = true; one_step = true
			KEY_R: _restart()
			KEY_F12: _debug_requested("screenshot")

func _draw() -> void:
	draw_rect(Rect2(0, 0, 1600, 1000), Color("080e18"))
	for x in range(0, 1600, 40):
		draw_line(Vector2(x, 85), Vector2(x, 988), Color(0.18, 0.34, 0.43, 0.06))
	for y in range(85, 1000, 40):
		draw_line(Vector2(12, y), Vector2(1588, y), Color(0.18, 0.34, 0.43, 0.06))
	# 子节点纹理叠在背景上；没有用CPU伪画右侧领土的回退路径。
	draw_rect(BATTLE_RECT.grow(3), Color("08121e"))
	draw_rect(BATTLE_RECT.grow(3), Color("345367"), false, 1.2)
	if not first_texture and font != null:
		var message := "正在编译 GPU Compute 管线…"
		if world != null and not world.error_message.is_empty(): message = world.error_message
		draw_string(font, BATTLE_RECT.position + Vector2(35, 360), message,
			HORIZONTAL_ALIGNMENT_LEFT, 780, 21, Color("ffb879"))

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		if world != null: world.shutdown()
		for old in retired: old.shutdown()
		# 渲染线程资源清理先排队，进程退出由Godot完成同步。
		get_tree().quit()
